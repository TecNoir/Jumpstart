$(function(){

	// Do jQuery or Zepto magic here

});